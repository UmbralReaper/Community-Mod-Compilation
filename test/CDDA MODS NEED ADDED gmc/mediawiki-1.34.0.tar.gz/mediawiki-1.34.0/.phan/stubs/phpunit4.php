<?php

/**
 * Some old classes from PHPUnit 4 that MediaWiki (conditionally) references.
 *
 * phpcs:ignoreFile
 */

class PHPUnit_TextUI_Command {

}
