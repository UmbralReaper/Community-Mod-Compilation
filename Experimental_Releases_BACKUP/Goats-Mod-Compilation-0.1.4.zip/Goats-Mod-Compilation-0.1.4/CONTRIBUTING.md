# Contributing
Always lint code that needs to be linted. If you are not sure lint it just in case.

Until I get a workflow I will be double checking every pr.

If you contribute you will be considered a part of the modding team. 
