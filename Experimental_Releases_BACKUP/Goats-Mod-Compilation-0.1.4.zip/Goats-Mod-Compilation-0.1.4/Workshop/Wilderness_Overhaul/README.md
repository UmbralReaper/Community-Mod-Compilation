# cdda-Wilderness_Overhaul
Original mod can be found in the following link: http://smf.cataclysmdda.com/index.php?topic=9568.0

Original mod by: MormonPartyboat

Additional work by: Malkeus

Maintained by: TheGoatGoad

Started off with Malkeus' work with the desire to make trees growable again.

Most of the work I did was around 2016-08-26, and it worked well, I've only done minimal work on getting it to load in experimental 0.C-22335-g620b23feab with no testing to speak of.

Not everything works, as I find things broken I deal with them.

NOTE that tree cutting has been split off into a seperate mod and repository for now since that required additional code to support.  See https://github.com/ProfoundDarkness/Cataclysm-DDA/tree/Tree_Harvesting for progress on that
