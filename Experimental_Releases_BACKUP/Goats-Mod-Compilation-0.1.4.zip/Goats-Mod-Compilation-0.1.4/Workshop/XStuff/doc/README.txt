======
XStuff
======

Mod by Enke


XStuff is a mod for Cataclysm: Dark Days Ahead that adds in all sorts of items. Mostly whatever pops into my head.
As a bonus, I included the good professions from my XProfessions mod, so you don't have to install both.
To install it, simply drag and drop into you Cataclysm:DDA mods directory, then activated during world generation. On Windows the directory is in <your Cata directory>\data\mods


For a semi-detailed overview of what's in here, see the Checklist.ods file. (You'll need to use a spreadsheet program like Excel to open it.)