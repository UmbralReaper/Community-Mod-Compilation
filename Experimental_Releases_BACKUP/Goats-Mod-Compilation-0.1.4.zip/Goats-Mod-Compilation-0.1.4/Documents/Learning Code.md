# Learning Code

Use the `home` key to get to the top.

- [links](#links)
  + [C#](#c)
  + [C++](#c-1)
  + [Python](#python)
  + [Java Script](#java-script)

---

# Links
#### Head-Category - [links](#links)


**Sub-Category's:**

[C#](#c#)\
[C++](#C++)\
[Python](#Python)

---
# C
#### Head-Category - [links](#links)\
#### Sub-Category - [C#](#c)

[C# Complete Tutorial From Beginner To Advance](https://www.youtube.com/watch?v=FPeGkedZykA&ab_channel=FLDevelopers)\
[C# Tutorial - Full Course for Beginners](https://www.youtube.com/watch?v=GhQdlIFylQ8&ab_channel=freeCodeCamp.org)

---
# C++
#### Head-Category - [links](#links)\
#### Sub-Category - [C++](#c-1)

[C++ Tutorial for Beginners - Full Course](https://www.youtube.com/watch?v=vLnPwxZdW4Y&ab_channel=freeCodeCamp.org)\
[C++ Programming All-in-One Tutorial Series](https://www.youtube.com/watch?v=_bYFu9mBnr4&ab_channel=CalebCurry)\
[C++ Tutorial From Basic to Advance](https://www.youtube.com/watch?v=mUQZ1qmKlLY&ab_channel=ExternCode)

---
# Python
#### Head-Category - [links](#links)\
#### Sub-Category - [Python](#python)

[Learn Python - Full Course for Beginners](https://www.youtube.com/watch?v=rfscVS0vtbw&ab_channel=freeCodeCamp.org)

---
# Java Script
#### Head-Category - [links](#links)\
#### Sub-Category - [Java Script](#java-script)

[Learn JavaScript - Full Course for Beginners](https://www.youtube.com/watch?v=PkZNo7MFNFg)\
[JavaScript Programming All-in-One Tutorial Series](https://www.youtube.com/watch?v=9M4XKi25I2M)
