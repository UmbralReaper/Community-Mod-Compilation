sqliteclysm
===========

Cataclysm Dark Days Ahead json to SQLite database and vice versa.
