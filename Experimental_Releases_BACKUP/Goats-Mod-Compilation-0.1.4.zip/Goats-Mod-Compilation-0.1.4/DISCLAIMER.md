Every mod is currently noted as being maintained by TheGoatGod unless it is actively (less than 3 months of inactivity) updated.

All mods are being maintained regardless of whether TheGoatGod's name is there or not.

Expect every mod to be working by the time 0.F is done.
