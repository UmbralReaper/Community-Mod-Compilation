---
name: Feature request
about: Suggest an idea for a mod or the project
title: ''
labels: ''
assignees: ''

---

**Mod Names** **Needs Improved**
Put the name of the mod(s) that you would like to be improved here.
Or
Put the idea or mod that you would like to see happen.

**Describe what you improved** **Needs Improved**
A clear and concise description of what you want to happen.
eg. like i improved `id`

**Additional context** **Needs Improved**
Add any other context or screenshots about the feature request here.
You can add more section/category/titles with two ** at the start and end
